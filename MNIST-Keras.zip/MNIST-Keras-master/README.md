# MNIST-Keras

A Custom Keras CNN model which scores an accuracy of 99.55% on the MNIST dataset.
